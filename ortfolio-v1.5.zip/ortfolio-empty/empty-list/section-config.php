<?php
$sectionName=basename(__DIR__);
$shuffleSectionThumbnails = false;