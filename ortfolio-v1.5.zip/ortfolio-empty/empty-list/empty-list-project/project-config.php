<?php 
$title = "List Item";
$creditOne = "Credit line one";
$creditTwo = "Credit line two";

$description = "Enter a project description here.";

// if you want to omit a project from the super gallery set $omit to true;
$omit = true;

// A list gallery project is pretty much just like your other standard projects, 
// except it also contains an $order variable. List-gallery projects are ordered
// in descending order (highest to lowest).
$order = 0;