<?php 
// Write up your blog post in HTML below.
// If you have any images in this posts folder, you can place them throughout
// your post by pasting the following between some php tags.
// 
// echo $blogImages[0];
//
// where blogImages is an array of all images in the folder, in alphabetical order. 
// $blogImages[0][0] is first image, $blogImages[0][1] is second, and so on...
?>

<p>This an empty blog post.</p>