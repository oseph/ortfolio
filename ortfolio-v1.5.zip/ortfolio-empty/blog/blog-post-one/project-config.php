<?php
// TYPE: blog post
$blog_title = "Blog Post Example";
$blog_intro = <<<INTRO
<p>If you want a short blog intro, put it here.</p>
INTRO;

$blog_date = "2020-10-25";
$omit = false;
$order = 1;