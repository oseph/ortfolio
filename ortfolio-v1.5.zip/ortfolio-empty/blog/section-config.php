<?php
$sectionName=basename(__DIR__);
$recentPostId = 2;