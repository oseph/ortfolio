<?php
$sectionName=basename(__DIR__);
$shuffleSectionThumbnails = true;