<?php 
/* To embed a video simply paste the YouTube/Vimeo embed code into the description variable. */
$title = 'Cleaning the Dust';
$creditOne = 'an embedded YouTube video from the Rijkmuseum';
$creditTwo = 'duration: 3min 46s';
$description = 'Below is a video from the Rijkmuseum. <p><iframe width="560" height="315" src="https://www.youtube.com/embed/9K3it8uViWY" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></p> ';

// if you want to omit a project from the super gallery set $omit to true;
$omit = false;