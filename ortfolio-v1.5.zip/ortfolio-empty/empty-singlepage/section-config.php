<?php
$sectionName=basename(__DIR__);