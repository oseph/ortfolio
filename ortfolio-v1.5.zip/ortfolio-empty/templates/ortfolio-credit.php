<?php echo <<<BLOG
<!--
***********************************************************************************
* This website uses ortfolio, a free and open template for image-based portfolios *
* Get it today at: github.com/oseph/ortfolio.                                     *
* Released under the MIT Licence.                                                 *
***********************************************************************************
-->

BLOG;