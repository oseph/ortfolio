<?php 
$title = "Empty project example";
$creditOne = "Credit line one";
$creditTwo = "Credit line two";

$description = "A description of this project.";

// if you want to omit a project from the super gallery set $omit to true;
$omit = true;