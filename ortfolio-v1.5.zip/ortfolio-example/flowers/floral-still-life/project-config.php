<?php 
$title = "Floral Still Life";
$creditOne = "Hans Bollongier, 1639 ";
$creditTwo = "67.6cm × w 53.3cm";

$description = "The still life was painted shortly after the Dutch stock market crashed in 1637, when many people went bankrupt due to the speculation in tulip bulbs.";

// if you want to omit a project from the super gallery set $omit to true;
$omit = true;