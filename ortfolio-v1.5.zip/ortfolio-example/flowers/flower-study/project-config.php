<?php 
$title = 'Flower Study';
$description = 'A lovely watercolour of flowers.';
$creditOne = 'John Jessop Hardwick, 1866';
$creditTwo = 'Watercolour, 29.2 x 38.1 cm';

// if you want to omit a project from the super gallery set $omit to true;
$omit = false;