<?php 
$title = "Irises";
$creditOne = "Vincent van Gogh, 1890";
$creditTwo = "Oil on canvas, 73.7 x 92.1 cm";
$description = "In May 1890, just before he checked himself out of the asylum at Saint-Rémy, Van Gogh painted four exuberant bouquets of spring flowers.";

// if you want to omit a project from the super gallery set $omit to true;
$omit = false;