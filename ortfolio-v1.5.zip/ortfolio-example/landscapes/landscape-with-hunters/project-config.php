<?php 
$title = "Landscape with Hunters";
$creditOne = "Ignacio de Iriarte, 1640-1685";
$creditTwo = "Oil on canvas, 104.5cm x 83.1 cm";
$description = "";

// if you want to omit a project from the super gallery set $omit to true;
$omit = false;