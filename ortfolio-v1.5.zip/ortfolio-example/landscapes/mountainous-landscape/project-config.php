<?php 
$title = "Mountainous landscape";
$creditOne = "Lucas van Valckenborch, 1582";
$creditTwo = "Oil on panel, 25cm x 35.5cm";

$description = "";

// if you want to omit a project from the super gallery set $omit to true;
$omit = false;