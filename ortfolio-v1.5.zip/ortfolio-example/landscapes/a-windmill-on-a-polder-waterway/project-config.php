<?php 
$title = "A Windmill on a Polder Waterway";
$creditOne = "Paul Joseph Constantin Gabriël, 1889";
$creditTwo = "Oil on canvas, 102 cm × 66 cm";
$description = "‘Our country is saturated with colour. ... I repeat, our country is not grey, not even in grey weather, nor are the dunes grey’, wrote Constant Gabriël in a letter. ";

// if you want to omit this project from the super gallery set $omit to true;
$omit = false;