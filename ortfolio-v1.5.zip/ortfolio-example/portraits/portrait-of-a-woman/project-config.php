<?php 
/* Enter project details below: */
$title = "Portrait of a Woman";
$description = "";
$creditOne = "Abraham de Vries, 1642";
$creditTwo = "Oil on panel, 68.5cm × 58cm";

// if you want to omit a project from the super gallery set $omit to true;
$omit = false;