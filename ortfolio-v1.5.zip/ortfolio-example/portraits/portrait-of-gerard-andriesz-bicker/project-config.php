<?php 
/* Enter your project details here: */
$title = "Portrait of Gerard Andriesz Bicker";
$creditOne = "Bartholomeus van der Helst, 1642";
$creditTwo = "Oil on panel, 94 cm × w 70.5cm";
$description = "Like his father, the twenty-year-old Gerard Bicker is portrayed as self-assured, his arm akimbo";

// if you want to omit a project from the super gallery set $omit to true;
$omit = false;