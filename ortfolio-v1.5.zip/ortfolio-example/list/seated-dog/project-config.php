<?php 
$title = "Seated Dog";
$creditOne = "Jacob Jordaens";
$creditTwo = "h 155mm × w 143mm";

$description = "This dog is probably a short-haired Vizsla, recognizable by the smooth coat and floppy ears. This breed of hunting dog was known for its excellent nose and tenacity in pointing and retrieving.";

// if you want to omit a project from the super gallery set $omit to true;
$omit = true;
$order = 0;