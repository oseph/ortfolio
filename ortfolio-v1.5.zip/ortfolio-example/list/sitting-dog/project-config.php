<?php 
$title = 'Sitting Dog';
$creditOne = 'Giovanni Domenico Tiepolo';
$creditTwo = 'Pen, h 139 x w 83mm';

$description = 'This drawing was probably used for a decoration in the villa of the Tiepolo family itself';

// if you want to omit a project from the super gallery set $omit to true;
$omit = false;
$order = 0;