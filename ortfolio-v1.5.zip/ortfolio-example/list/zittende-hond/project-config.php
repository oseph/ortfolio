<?php 
$title = "Zittende hond";
$creditOne = "Bernhard Schreuder";
$creditTwo = "print, h 137 mm × w 104 mm";
$description = "No description. From the Rijksmuseum collection.";

// if you want to omit a project from the super gallery set $omit to true;
$omit = false;
$order = 0;