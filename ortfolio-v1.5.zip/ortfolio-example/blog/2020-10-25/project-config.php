<?php
// TYPE: blog post
$blog_title = "Blog Post One";
$blog_intro = <<<INTRO
<p>This is a blog intro for the first blog post.</p>
INTRO;

$blog_date = "2020-10-25";
$omit = false;
$order = 1;