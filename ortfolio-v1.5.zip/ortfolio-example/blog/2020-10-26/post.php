<?php echo $blogImages[0]; ?>

<p>This is yet another blog post. The image of the above print, <em>Oude vrouw met bijbel op de schoot, mogelijk de moeder van Rembrandt</em>, was created by Pieter Louw, after Rembrandt van Rijn, sometime around 1743–1800.</p>