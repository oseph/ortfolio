<?php
// TYPE: blog post
$blog_title = "Blog Post Two";
$blog_intro = <<<INTRO
<p>This is a more recent entry.</p>
INTRO;

$blog_date = "2020-10-26";
$omit = false;
$order = 2;